
Date of compilation: 9-June-2018
Xiaofan Chen <xiaofanc AT gmail dot com)

Please use libftdi mailing list for support. I do not
reply to technical questions through private email.

To use libftdi1 under Windows, you need to use libusb 
and supported drivers.

The copyright information about libftdi1 and libusb are 
inside the copyright directory.

The html_doc directory is the doxygen generated HTML document 
for libftdi1-1.4git. libusb is at the following URL.
  http://libusb.info/

The bin directory contains the dlls and example programs for 
libftdi1-1.4git and libusb 1.0.22 Windows. 

The source code libftdi1-1.4git (libftdi-91dbb65.tar.gz) and 
libusb-1.0.22 release for the build are also included in the 
src directory.

Tools used to build this package:
  MSYS2 up to date as of 9-June-2018 
  (gcc 7.3, doxygen 1.8.14, swig 3.0.12, Boost 1.67, 
   libusb-1.0.22, libconfuse 3.2.1, etc)
  CMake 3.11.3: http://www.cmake.org/
  Python 3.6.5 32bit/64bit: http://www.python.org

MSYS2 has CMake and Python 3.6 as well but I had some problems 
with them when building the Python bindings. Anyway the
Python bindings may not work well. You may have better luck
with pyftdi, pylibftdi, etc.
